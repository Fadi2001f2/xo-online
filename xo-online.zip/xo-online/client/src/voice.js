// شبكة صوت WebRTC (Mesh): كل عضو يتصل مباشرة بكل الأعضاء الآخرين.
// - الإرسال: لا يُرسل الميكروفون إلا إذا سمح السيرفر (canSpeak) وفتح المستخدم المايك.
// - الاستقبال: لا يُشغَّل صوت أي عضو إلا إذا كان ضمن قائمة speakers القادمة من السيرفر،
//   لذلك حتى لو حاول عميل معدّل الإرسال بعد كتمه، لن يسمعه أحد.

export class VoiceMesh {
  constructor(socket, iceServers, onChange) {
    this.socket = socket;
    this.iceServers = iceServers;
    this.onChange = onChange || (() => {});
    this.peers = new Map(); // id -> { pc, tx, pending: [], audio }
    this.localStream = null;
    this.micOn = false;
    this.speakerOn = true;
    this.canSpeak = false;
    this.speakers = new Set();
    this.autoplayBlocked = false;
    this.micError = null;
    this.onSignal = this.onSignal.bind(this);
    socket.on('rtc:signal', this.onSignal);
  }

  // ---------- اتصالات ----------
  createPeer(id) {
    this.removePeer(id);
    const pc = new RTCPeerConnection({ iceServers: this.iceServers });
    const entry = { pc, tx: null, pending: [], audio: null };
    pc.onicecandidate = (e) => {
      if (e.candidate) this.socket.emit('rtc:signal', { to: id, data: { candidate: e.candidate } });
    };
    pc.ontrack = (e) => {
      const stream = e.streams[0] || new MediaStream([e.track]);
      this.attachAudio(id, entry, stream);
    };
    pc.onconnectionstatechange = () => {
      if (pc.connectionState === 'failed' && pc.restartIce) pc.restartIce();
      this.onChange();
    };
    this.peers.set(id, entry);
    return entry;
  }

  /** العضو الجديد يبدأ الاتصال بكل الموجودين (يمنع تصادم العروض) */
  async call(id) {
    try {
      const entry = this.createPeer(id);
      entry.tx = entry.pc.addTransceiver('audio', { direction: 'sendrecv' });
      await this.applyTrack(entry);
      await entry.pc.setLocalDescription(await entry.pc.createOffer());
      this.socket.emit('rtc:signal', { to: id, data: { sdp: entry.pc.localDescription } });
    } catch (err) {
      console.warn('call failed', id, err);
    }
  }

  async onSignal({ from, data }) {
    try {
      if (data.sdp?.type === 'offer') {
        const entry = this.createPeer(from);
        await entry.pc.setRemoteDescription(data.sdp);
        entry.tx = entry.pc.getTransceivers().find((t) => t.receiver.track.kind === 'audio');
        if (entry.tx) entry.tx.direction = 'sendrecv'; // حتى نستطيع الإرسال لاحقًا بدون إعادة تفاوض
        await this.applyTrack(entry);
        await entry.pc.setLocalDescription(await entry.pc.createAnswer());
        this.socket.emit('rtc:signal', { to: from, data: { sdp: entry.pc.localDescription } });
        await this.flush(entry);
      } else if (data.sdp?.type === 'answer') {
        const entry = this.peers.get(from);
        if (entry && entry.pc.signalingState === 'have-local-offer') {
          await entry.pc.setRemoteDescription(data.sdp);
          await this.flush(entry);
        }
      } else if (data.candidate) {
        const entry = this.peers.get(from);
        if (!entry) return;
        if (entry.pc.remoteDescription) await entry.pc.addIceCandidate(data.candidate);
        else entry.pending.push(data.candidate);
      }
    } catch (err) {
      console.warn('signal error', err);
    }
  }

  async flush(entry) {
    const list = entry.pending.splice(0);
    for (const c of list) {
      try { await entry.pc.addIceCandidate(c); } catch {}
    }
  }

  removePeer(id) {
    const entry = this.peers.get(id);
    if (!entry) return;
    try { entry.pc.close(); } catch {}
    if (entry.audio) { entry.audio.srcObject = null; entry.audio.remove(); }
    this.peers.delete(id);
    this.onChange();
  }

  // ---------- تشغيل الصوت ----------
  attachAudio(id, entry, stream) {
    if (!entry.audio) {
      const el = document.createElement('audio');
      el.autoplay = true;
      el.setAttribute('playsinline', '');
      el.style.display = 'none';
      document.body.appendChild(el);
      entry.audio = el;
    }
    entry.audio.srcObject = stream;
    this.updateAudio(id, entry);
  }

  updateAudio(id, entry) {
    if (!entry.audio) return;
    entry.audio.muted = !this.speakerOn || !this.speakers.has(id);
    const p = entry.audio.play();
    if (p) p.then(() => { if (this.autoplayBlocked) { this.autoplayBlocked = false; this.onChange(); } })
      .catch(() => { this.autoplayBlocked = true; this.onChange(); });
  }

  /** يُستدعى بعد ضغطة المستخدم لفك قيود التشغيل التلقائي (iOS/Safari) */
  unlockAudio() {
    for (const [id, e] of this.peers) this.updateAudio(id, e);
  }

  // ---------- الميكروفون ----------
  async applyTrack(entry) {
    if (!entry.tx) return;
    const track = this.canSpeak && this.micOn && this.localStream ? this.localStream.getAudioTracks()[0] : null;
    try { await entry.tx.sender.replaceTrack(track); } catch {}
  }

  async setMic(on) {
    this.micError = null;
    if (on && !this.canSpeak) on = false;
    if (on && !this.localStream) {
      if (!window.isSecureContext || !navigator.mediaDevices?.getUserMedia) {
        this.micError = 'الميكروفون يحتاج HTTPS';
        this.onChange();
        return false;
      }
      try {
        this.localStream = await navigator.mediaDevices.getUserMedia({
          audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
          video: false,
        });
      } catch (err) {
        this.micError = err.name === 'NotAllowedError' ? 'تم رفض إذن الميكروفون' : 'تعذر تشغيل الميكروفون';
        this.onChange();
        return false;
      }
    }
    this.micOn = on;
    if (!on && this.localStream) {
      // إيقاف كامل للمايك (تنطفئ إشارة المتصفح)
      this.localStream.getTracks().forEach((t) => t.stop());
      this.localStream = null;
    }
    await Promise.all([...this.peers.values()].map((e) => this.applyTrack(e)));
    this.socket.emit('voice:mic', { on });
    this.onChange();
    return true;
  }

  setSpeaker(on) {
    this.speakerOn = on;
    this.unlockAudio();
    this.onChange();
  }

  /** تحديث الصلاحيات القادمة من السيرفر */
  setPermissions(canSpeak, speakers) {
    this.canSpeak = canSpeak;
    this.speakers = new Set(speakers);
    if (!canSpeak && this.micOn) this.setMic(false);
    for (const [id, e] of this.peers) this.updateAudio(id, e);
  }

  destroy() {
    this.socket.off('rtc:signal', this.onSignal);
    for (const id of [...this.peers.keys()]) this.removePeer(id);
    if (this.localStream) this.localStream.getTracks().forEach((t) => t.stop());
    this.localStream = null;
    this.micOn = false;
  }
}
