import React from 'react';

export default function Board({ board, result, canPlay, onMove }) {
  const winLine = new Set(result?.line || []);
  return (
    <div className={`board ${canPlay ? 'active' : ''}`} role="grid" aria-label="لوحة اللعب">
      {board.map((cell, i) => (
        <button
          key={i}
          className={`cell ${cell ? cell.toLowerCase() : ''} ${winLine.has(i) ? 'win' : ''}`}
          disabled={!canPlay || !!cell}
          onClick={() => onMove(i)}
          aria-label={`خانة ${i + 1} ${cell || 'فارغة'}`}
        >
          {cell === 'X' && (
            <svg viewBox="0 0 100 100"><path d="M25 25L75 75M75 25L25 75" /></svg>
          )}
          {cell === 'O' && (
            <svg viewBox="0 0 100 100"><circle cx="50" cy="50" r="27" /></svg>
          )}
        </button>
      ))}
    </div>
  );
}
