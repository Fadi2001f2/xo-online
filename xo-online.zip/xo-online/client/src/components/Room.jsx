import React, { useEffect, useReducer, useRef, useState } from 'react';
import Board from './Board.jsx';
import { VoiceMesh } from '../voice.js';
import {
  socket, emitAck, fetchIce, getClientId, getName, setName, getHostKey, errText, roomUrl,
} from '../lib.js';

const KICK_TEXT = {
  kicked: 'قام مدير الغرفة بطردك.',
  banned: 'قام مدير الغرفة بحظرك من هذه الغرفة.',
  replaced: 'تم فتح الغرفة من نافذة أخرى على نفس الجهاز.',
};

export default function Room({ roomId, token, navigate }) {
  const [nameInput, setNameInput] = useState(getName());
  const [started, setStarted] = useState(!!getName());
  const [phase, setPhase] = useState('joining'); // joining | in | error | kicked
  const [state, setState] = useState(null);
  const [error, setError] = useState('');
  const [toast, setToast] = useState('');
  const [online, setOnline] = useState(true);
  const [, rerender] = useReducer((x) => x + 1, 0);
  const voiceRef = useRef(null);
  const iceRef = useRef(null);
  const stoppedRef = useRef(false);
  const toastTimer = useRef(null);

  const flash = (msg) => {
    setToast(msg);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(''), 2600);
  };

  useEffect(() => {
    if (!started) return;
    let alive = true;
    stoppedRef.current = false;

    async function join() {
      if (stoppedRef.current) return;
      if (!iceRef.current) iceRef.current = await fetchIce();
      const res = await emitAck('room:join', {
        roomId, token, hostKey: getHostKey(roomId), name: getName(), clientId: getClientId(),
      });
      if (!alive) return;
      if (!res?.ok) {
        stoppedRef.current = true;
        setError(errText(res?.error));
        setPhase('error');
        return;
      }
      voiceRef.current?.destroy();
      const v = new VoiceMesh(socket, iceRef.current, rerender);
      voiceRef.current = v;
      setState(res.state);
      v.setPermissions(res.state.you.canSpeak, res.state.speakers);
      setPhase('in');
      res.peers.forEach((id) => v.call(id));
    }

    const onState = (s) => {
      setState(s);
      voiceRef.current?.setPermissions(!!s.you?.canSpeak, s.speakers);
    };
    const onPeerLeft = ({ id }) => voiceRef.current?.removePeer(id);
    const onKicked = ({ reason }) => {
      stoppedRef.current = true;
      voiceRef.current?.destroy();
      voiceRef.current = null;
      setError(KICK_TEXT[reason] || 'تم إخراجك من الغرفة');
      setPhase('kicked');
    };
    const onForceMute = () => { voiceRef.current?.setMic(false); flash('قام المدير بكتم صوتك'); };
    const onConnect = () => { setOnline(true); join(); };
    const onDisconnect = () => setOnline(false);

    socket.on('room:state', onState);
    socket.on('peer:left', onPeerLeft);
    socket.on('room:kicked', onKicked);
    socket.on('voice:forceMute', onForceMute);
    socket.on('connect', onConnect);
    socket.on('disconnect', onDisconnect);
    if (socket.connected) join(); else socket.connect();

    return () => {
      alive = false;
      stoppedRef.current = true;
      socket.off('room:state', onState);
      socket.off('peer:left', onPeerLeft);
      socket.off('room:kicked', onKicked);
      socket.off('voice:forceMute', onForceMute);
      socket.off('connect', onConnect);
      socket.off('disconnect', onDisconnect);
      socket.emit('room:leave');
      voiceRef.current?.destroy();
      voiceRef.current = null;
    };
  }, [started, roomId, token]);

  // ---------- شاشة إدخال الاسم ----------
  if (!started) {
    return (
      <main className="center">
        <form className="card narrow" onSubmit={(e) => {
          e.preventDefault();
          if (!nameInput.trim()) return;
          setName(nameInput);
          setStarted(true);
        }}>
          <h2>الدخول إلى الغرفة</h2>
          <label htmlFor="n">اسمك</label>
          <input id="n" autoFocus value={nameInput} maxLength={20} onChange={(e) => setNameInput(e.target.value)} />
          <button className="btn primary big">دخول</button>
        </form>
      </main>
    );
  }

  if (phase === 'error' || phase === 'kicked') {
    return (
      <main className="center">
        <div className="card narrow">
          <h2>{phase === 'kicked' ? 'خرجت من الغرفة' : 'تعذر الدخول'}</h2>
          <p className="muted">{error}</p>
          <button className="btn primary" onClick={() => navigate('/')}>العودة للرئيسية</button>
        </div>
      </main>
    );
  }

  if (!state) {
    return <main className="center"><div className="spinner" aria-label="جارٍ الاتصال" /></main>;
  }

  // ---------- الغرفة ----------
  const v = voiceRef.current;
  const { you, players, board, turn, result, scores, spectators, links, locked, rematchVotes } = state;
  const isPlayer = you.role === 'X' || you.role === 'O';
  const bothOnline = players.X?.online && players.O?.online;
  const canPlay = isPlayer && !result && bothOnline && turn === you.role;

  let status;
  if (result) status = result.winner === 'draw' ? 'تعادل! 🤝' : `🏆 فاز ${players[result.winner]?.name} (${result.winner})`;
  else if (!players.O) status = 'بانتظار اللاعب الثاني… أرسل له رابط الدعوة';
  else if (!bothOnline) status = 'أحد اللاعبين غير متصل حاليًا…';
  else if (isPlayer) status = turn === you.role ? 'دورك الآن ✨' : `دور ${players[turn].name}`;
  else status = `دور ${players[turn].name} (${turn})`;

  const move = async (i) => {
    const r = await emitAck('game:move', { index: i });
    if (!r?.ok) flash(errText(r?.error));
  };
  const rematch = async () => {
    const r = await emitAck('game:rematch', {});
    if (!r?.ok) flash(errText(r?.error));
  };
  const host = async (action, target, confirmText) => {
    if (confirmText && !window.confirm(confirmText)) return;
    const r = await emitAck('host:action', { action, target });
    if (!r?.ok) flash(errText(r?.error));
  };
  const copy = async (text, label) => {
    try {
      if (navigator.share && /Mobi|Android/i.test(navigator.userAgent)) {
        await navigator.share({ title: 'XO Online', text: label, url: text });
        return;
      }
      await navigator.clipboard.writeText(text);
      flash('تم نسخ الرابط ✅');
    } catch {
      window.prompt('انسخ الرابط:', text);
    }
  };
  const toggleMic = async () => {
    if (!v) return;
    await v.setMic(!v.micOn);
    if (v.micError) flash(v.micError);
  };

  const PlayerCard = ({ role }) => {
    const p = players[role];
    const active = !result && turn === role && bothOnline;
    return (
      <div className={`player ${role.toLowerCase()} ${active ? 'turn' : ''} ${result?.winner === role ? 'winner' : ''}`}>
        <div className="mark">{role}</div>
        <div className="pinfo">
          <div className="pname">
            {p ? p.name : '— بانتظار لاعب —'}
            {p?.isHost && <span className="tag">المدير</span>}
            {p && p.id === you.id && <span className="tag you">أنت</span>}
          </div>
          <div className="pmeta">
            <span className={`dot ${p?.online ? 'on' : ''}`} />
            {p ? (p.online ? 'متصل' : 'غير متصل') : ''}
            {p?.online && <span className="mic-ind">{!p.canSpeak ? '🔇 مكتوم' : p.micOn ? '🎙️' : '🎙️✕'}</span>}
          </div>
        </div>
        <div className="pscore">{scores[role]}</div>
        {you.isHost && role === 'O' && p?.online && (
          <div className="host-tools">
            {p.canSpeak
              ? <button className="chip" onClick={() => host('mute', p.id)}>كتم</button>
              : <button className="chip" onClick={() => host('allowSpeak', p.id)}>سماح بالكلام</button>}
            <button className="chip danger" onClick={() => host('kick', p.id, `طرد ${p.name}؟`)}>طرد</button>
          </div>
        )}
      </div>
    );
  };

  return (
    <main className="room">
      {!online && <div className="banner warn">انقطع الاتصال… جارٍ إعادة المحاولة</div>}
      {!window.isSecureContext && <div className="banner warn">الصوت يحتاج HTTPS — افتح الموقع عبر https://</div>}
      {v?.autoplayBlocked && (
        <button className="banner action" onClick={() => v.unlockAudio()}>🔊 اضغط هنا لتفعيل سماع الصوت</button>
      )}

      <div className="layout">
        <section className="game card">
          <div className="players">
            <PlayerCard role="X" />
            <div className="vs">
              <span>VS</span>
              <small>تعادل {scores.draw}</small>
            </div>
            <PlayerCard role="O" />
          </div>

          <div className={`status ${result ? 'done' : ''}`}>{status}</div>
          <Board board={board} result={result} canPlay={canPlay} onMove={move} />

          <div className="controls">
            <button
              className={`btn round ${v?.micOn ? 'on' : ''}`}
              onClick={toggleMic}
              disabled={!you.canSpeak}
              title={you.canSpeak ? 'الميكروفون' : 'تحتاج إذن المدير للكلام'}
            >
              {v?.micOn ? '🎙️ المايك مفتوح' : '🎙️ المايك مغلق'}
            </button>
            <button className={`btn round ${v?.speakerOn ? 'on' : ''}`} onClick={() => v?.setSpeaker(!v.speakerOn)}>
              {v?.speakerOn ? '🔊 السماعة' : '🔈 السماعة مغلقة'}
            </button>
            {isPlayer && result && (
              <button className="btn primary" onClick={rematch} disabled={rematchVotes.includes(you.role)}>
                {rematchVotes.includes(you.role) ? 'بانتظار موافقة الخصم…' : rematchVotes.length ? 'الخصم يريد جولة جديدة — وافق' : '🔄 إعادة اللعب'}
              </button>
            )}
          </div>
          {!you.canSpeak && <p className="muted small">أنت مشاهد — تستطيع السماع، والكلام يحتاج إذن المدير.</p>}
        </section>

        <aside className="side">
          {links && (
            <div className="card">
              <h3>روابط الدعوة</h3>
              {links.playToken && (
                <div className="link-row">
                  <div><b>رابط اللاعب الثاني (O)</b><small>{players.O ? 'المقعد مشغول' : 'أرسله لخصمك'}</small></div>
                  <button className="btn" onClick={() => copy(roomUrl(roomId, links.playToken), 'تعال العب معي XO')}>نسخ</button>
                </div>
              )}
              <div className="link-row">
                <div><b>رابط المشاهدين</b><small>للمشاهدة فقط</small></div>
                <button className="btn" onClick={() => copy(roomUrl(roomId, links.watchToken), 'شاهد مباراة XO')}>نسخ</button>
              </div>
              {you.isHost && (
                <div className="host-row">
                  <button className={`btn ${locked ? 'danger' : ''}`} onClick={() => host(locked ? 'unlock' : 'lock')}>
                    {locked ? '🔒 دخول المشاهدين مغلق' : '🔓 دخول المشاهدين مفتوح'}
                  </button>
                  <button className="btn ghost" onClick={() => host('resetScores', null, 'تصفير النتائج؟')}>تصفير النتائج</button>
                </div>
              )}
            </div>
          )}

          <div className="card">
            <h3>المشاهدون <span className="count">{spectators.length}/{state.maxSpectators}</span></h3>
            {spectators.length === 0 && <p className="muted small">لا يوجد مشاهدون بعد</p>}
            <ul className="spectators">
              {spectators.map((s) => (
                <li key={s.id}>
                  <div className="sname">
                    <span>{s.name}{s.id === you.id && <span className="tag you">أنت</span>}</span>
                    <small>{s.canSpeak ? (s.micOn ? '🎙️ يتكلم' : '🎙️ مسموح له') : '🔇 مستمع'}</small>
                  </div>
                  {you.isHost && (
                    <div className="host-tools">
                      {s.canSpeak
                        ? <button className="chip" onClick={() => host('mute', s.id)}>كتم</button>
                        : <button className="chip ok" onClick={() => host('allowSpeak', s.id)}>سماح بالكلام</button>}
                      <button className="chip danger" onClick={() => host('kick', s.id, `طرد ${s.name}؟`)}>طرد</button>
                      <button className="chip danger" onClick={() => host('ban', s.id, `حظر ${s.name} نهائيًا من الغرفة؟`)}>حظر</button>
                    </div>
                  )}
                </li>
              ))}
            </ul>
          </div>

          <button className="btn ghost wide" onClick={() => navigate('/')}>مغادرة الغرفة</button>
        </aside>
      </div>

      {toast && <div className="toast">{toast}</div>}
    </main>
  );
}
