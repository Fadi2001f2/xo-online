import React, { useState } from 'react';
import { socket, emitAck, getName, setName, setHostKey, errText } from '../lib.js';

export default function Home({ navigate }) {
  const [name, setN] = useState(getName());
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  async function create(e) {
    e.preventDefault();
    if (!name.trim()) return setErr('اكتب اسمك أولًا');
    setBusy(true);
    setErr('');
    setName(name);
    if (!socket.connected) socket.connect();
    const res = await emitAck('room:create', { name });
    setBusy(false);
    if (!res?.ok) return setErr(errText(res?.error));
    setHostKey(res.roomId, res.hostKey);
    navigate(`/r/${res.roomId}`);
  }

  return (
    <main className="home">
      <section className="hero">
        <h1>XO <span className="grad">أونلاين</span></h1>
        <p>أنشئ غرفة، أرسل الرابط لصديقك، والعبوا مباشرة مع دردشة صوتية ومشاهدين.</p>
        <form className="card create" onSubmit={create}>
          <label htmlFor="name">اسمك</label>
          <input id="name" value={name} maxLength={20} onChange={(e) => setN(e.target.value)} placeholder="مثال: أحمد" autoComplete="nickname" />
          <button className="btn primary big" disabled={busy}>{busy ? 'جارٍ الإنشاء…' : 'إنشاء غرفة جديدة'}</button>
          {err && <div className="error">{err}</div>}
        </form>
        <ul className="features">
          <li><b>⚡ مباشر</b><span>كل حركة تظهر فورًا للجميع</span></li>
          <li><b>🎙️ صوت</b><span>تحدث مع خصمك أثناء اللعب</span></li>
          <li><b>👀 مشاهدون</b><span>رابط خاص للأصدقاء</span></li>
          <li><b>🛡️ تحكم</b><span>طرد، حظر، كتم، وقفل الغرفة</span></li>
        </ul>
      </section>
    </main>
  );
}
