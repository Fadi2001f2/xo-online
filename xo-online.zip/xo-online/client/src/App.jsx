import React, { useEffect, useState } from 'react';
import Home from './components/Home.jsx';
import Room from './components/Room.jsx';

function parseRoute() {
  const m = location.pathname.match(/^\/r\/([A-Za-z0-9_-]{4,32})\/?$/);
  if (!m) return { page: 'home' };
  return { page: 'room', roomId: m[1], token: new URLSearchParams(location.search).get('t') || '' };
}

export default function App() {
  const [route, setRoute] = useState(parseRoute);
  useEffect(() => {
    const onPop = () => setRoute(parseRoute());
    window.addEventListener('popstate', onPop);
    return () => window.removeEventListener('popstate', onPop);
  }, []);

  const navigate = (url) => {
    history.pushState(null, '', url);
    setRoute(parseRoute());
  };

  return (
    <div className="app">
      <header className="topbar">
        <a className="logo" href="/" onClick={(e) => { e.preventDefault(); navigate('/'); }}>
          <span className="x">X</span><span className="o">O</span> <b>Online</b>
        </a>
      </header>
      {route.page === 'home'
        ? <Home navigate={navigate} />
        : <Room key={route.roomId} roomId={route.roomId} token={route.token} navigate={navigate} />}
    </div>
  );
}
