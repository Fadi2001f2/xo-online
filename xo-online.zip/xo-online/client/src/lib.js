import { io } from 'socket.io-client';

// اتصال واحد مشترك بنفس النطاق (يعمل خلف HTTPS تلقائيًا كـ WSS)
export const socket = io(import.meta.env.VITE_SERVER_URL || undefined, {
  autoConnect: false,
  transports: ['websocket', 'polling'],
});

export function emitAck(event, data, timeout = 8000) {
  return new Promise((resolve) => {
    socket.timeout(timeout).emit(event, data, (err, res) => resolve(err ? { ok: false, error: 'timeout' } : res));
  });
}

// معرف ثابت لهذا الجهاز/المتصفح — يُستخدم لإعادة الاتصال وللحظر
export function getClientId() {
  let id = localStorage.getItem('xo:clientId');
  if (!id) {
    id = crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).slice(2) + Date.now().toString(36);
    localStorage.setItem('xo:clientId', id);
  }
  return id;
}

export const getName = () => localStorage.getItem('xo:name') || '';
export const setName = (n) => localStorage.setItem('xo:name', n.trim().slice(0, 20));
export const getHostKey = (roomId) => localStorage.getItem('xo:host:' + roomId);
export const setHostKey = (roomId, k) => localStorage.setItem('xo:host:' + roomId, k);

export async function fetchIce() {
  try {
    const base = import.meta.env.VITE_SERVER_URL || '';
    const r = await fetch(base + '/api/ice', { cache: 'no-store' });
    const j = await r.json();
    return j.iceServers;
  } catch {
    return [{ urls: 'stun:stun.l.google.com:19302' }];
  }
}

export const ERRORS = {
  no_room: 'الغرفة غير موجودة أو انتهت صلاحيتها',
  bad_link: 'رابط الدعوة غير صالح',
  banned: 'تم منعك من دخول هذه الغرفة',
  locked: 'المدير أغلق دخول مشاهدين جدد',
  full: 'الغرفة ممتلئة بالمشاهدين',
  not_your_turn: 'ليس دورك',
  cell_taken: 'الخانة محجوزة',
  waiting_player: 'بانتظار دخول اللاعب الثاني',
  game_over: 'انتهت الجولة',
  not_host: 'هذا الإجراء للمدير فقط',
  timeout: 'انقطع الاتصال، حاول مرة أخرى',
  rate_limited: 'طلبات كثيرة، تمهل قليلًا',
};
export const errText = (e) => ERRORS[e] || 'حدث خطأ';

export function roomUrl(roomId, token) {
  return `${location.origin}/r/${roomId}${token ? `?t=${token}` : ''}`;
}
