import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// في التطوير: Vite على 5173 ويحوّل الطلبات للسيرفر على 3001
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/socket.io': { target: 'http://localhost:3001', ws: true },
      '/api': 'http://localhost:3001',
    },
  },
});
