import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Room } from '../src/rooms.js';
import { checkResult } from '../src/game.js';

const setup = () => {
  const room = new Room({ hostName: 'Host' });
  room.join('sX', { clientId: 'client-host-1', name: 'Host', hostKey: room.hostKey, ip: '1.1.1.1' });
  room.join('sO', { clientId: 'client-guest-1', name: 'Guest', token: room.playToken, ip: '2.2.2.2' });
  room.join('sS', { clientId: 'client-watch-1', name: 'Watcher', token: room.watchToken, ip: '3.3.3.3' });
  return room;
};

test('winner and draw detection', () => {
  assert.equal(checkResult(['X', 'X', 'X', null, null, null, null, null, null]).winner, 'X');
  assert.equal(checkResult(['X', 'O', 'X', 'X', 'O', 'O', 'O', 'X', 'X']).winner, 'draw');
  assert.equal(checkResult(Array(9).fill(null)), null);
});

test('roles assigned by link', () => {
  const r = setup();
  assert.equal(r.members.get('sX').role, 'X');
  assert.equal(r.members.get('sX').isHost, true);
  assert.equal(r.members.get('sO').role, 'O');
  assert.equal(r.members.get('sS').role, 'spectator');
  assert.equal(r.members.get('sS').canSpeak, false);
  // رابط مزيف
  assert.equal(r.join('sZ', { clientId: 'client-zzzz', token: 'nope' }).error, 'bad_link');
  // لاعب ثالث برابط اللعب يصبح مشاهدًا
  r.join('s3', { clientId: 'client-third', token: r.playToken, ip: '4.4.4.4' });
  assert.equal(r.members.get('s3').role, 'spectator');
});

test('turn enforcement and win', () => {
  const r = setup();
  assert.equal(r.move('sO', 0).error, 'not_your_turn');
  assert.equal(r.move('sS', 0).error, 'not_player');
  assert.ok(r.move('sX', 0).ok);
  assert.equal(r.move('sO', 0).error, 'cell_taken');
  assert.ok(r.move('sO', 3).ok);
  r.move('sX', 1); r.move('sO', 4);
  assert.ok(r.move('sX', 2).ok);
  assert.equal(r.result.winner, 'X');
  assert.equal(r.scores.X, 1);
  assert.equal(r.move('sO', 5).error, 'game_over');
  // إعادة اللعب تحتاج صوتي اللاعبين وتبدّل البادئ
  r.voteRematch('sX');
  assert.ok(r.result);
  r.voteRematch('sO');
  assert.equal(r.result, null);
  assert.equal(r.turn, 'O');
});

test('host permissions enforced', () => {
  const r = setup();
  assert.equal(r.hostAction('sO', { action: 'kick', target: 'sS' }).error, 'not_host');
  assert.equal(r.hostAction('sS', { action: 'lock' }).error, 'not_host');
  assert.equal(r.hostAction('sX', { action: 'kick', target: 'sX' }).error, 'cannot_target_host');

  assert.ok(r.hostAction('sX', { action: 'allowSpeak', target: 'sS' }).ok);
  assert.equal(r.members.get('sS').canSpeak, true);
  assert.ok(r.stateFor('sO').speakers.includes('sS'));
  assert.ok(r.hostAction('sX', { action: 'mute', target: 'sS' }).ok);
  assert.ok(!r.stateFor('sO').speakers.includes('sS'));

  assert.ok(r.hostAction('sX', { action: 'ban', target: 'sS' }).ok);
  assert.equal(r.members.has('sS'), false);
  assert.equal(r.join('sS2', { clientId: 'client-watch-1', token: r.watchToken, ip: '9.9.9.9' }).error, 'banned');
  assert.equal(r.join('sS3', { clientId: 'client-new-xx', token: r.watchToken, ip: '3.3.3.3' }).error, 'banned');

  assert.ok(r.hostAction('sX', { action: 'lock' }).ok);
  assert.equal(r.join('sS4', { clientId: 'client-other', token: r.watchToken, ip: '5.5.5.5' }).error, 'locked');
});

test('secrets only visible to the right people', () => {
  const r = setup();
  assert.ok(r.stateFor('sX').links.playToken);
  assert.equal(r.stateFor('sO').links.playToken, undefined);
  assert.equal(r.stateFor('sS').links, null);
  assert.ok(!JSON.stringify(r.stateFor('sX')).includes(r.hostKey));
  assert.ok(!JSON.stringify(r.stateFor('sX')).includes('client-guest-1'));
});

test('reconnect keeps player seat', () => {
  const r = setup();
  r.move('sX', 4);
  r.leave('sO');
  assert.equal(r.move('sX', 0).error, 'waiting_player');
  r.join('sO2', { clientId: 'client-guest-1', token: r.playToken, ip: '2.2.2.2' });
  assert.equal(r.members.get('sO2').role, 'O');
  assert.ok(r.move('sO2', 0).ok);
});
