// اختبار شامل عبر الشبكة: لاعبان + مشاهد كأجهزة منفصلة (اتصالات Socket.IO مستقلة)
// التشغيل: npm start في نافذة، ثم: URL=http://localhost:3001 npm run e2e
// أو على السيرفر المنشور: URL=https://xo.example.com npm run e2e
import { io } from 'socket.io-client';
import assert from 'node:assert/strict';

const URL = process.env.URL || 'http://localhost:3001';
const connect = () => new Promise((res, rej) => {
  const s = io(URL, { transports: ['websocket'], forceNew: true });
  s.once('connect', () => res(s));
  s.once('connect_error', rej);
});
const call = (s, ev, data) => new Promise((res) => s.emit(ev, data, res));
const waitFor = (s, ev, pred = () => true, ms = 3000) => new Promise((res, rej) => {
  const t = setTimeout(() => rej(new Error('timeout waiting ' + ev)), ms);
  const h = (d) => { if (pred(d)) { clearTimeout(t); s.off(ev, h); res(d); } };
  s.on(ev, h);
});

const host = await connect(), guest = await connect(), watcher = await connect();
const created = await call(host, 'room:create', { name: 'Host' });
const j1 = await call(host, 'room:join', { roomId: created.roomId, hostKey: created.hostKey, clientId: 'e2e-host-' + Date.now(), name: 'Host' });
assert.ok(j1.ok);
const { playToken, watchToken } = j1.state.links;

const j2 = await call(guest, 'room:join', { roomId: created.roomId, token: playToken, clientId: 'e2e-guest-' + Date.now(), name: 'Guest' });
assert.equal(j2.state.you.role, 'O');
const j3 = await call(watcher, 'room:join', { roomId: created.roomId, token: watchToken, clientId: 'e2e-watch-' + Date.now(), name: 'Watcher' });
assert.equal(j3.state.you.role, 'spectator');
console.log('✓ دخول لاعبين ومشاهد');

// مزامنة الحركة: X يلعب ← تظهر عند O والمشاهد
const seenByGuest = waitFor(guest, 'room:state', (s) => s.board[4] === 'X');
const seenByWatcher = waitFor(watcher, 'room:state', (s) => s.board[4] === 'X');
assert.ok((await call(host, 'game:move', { index: 4 })).ok);
await Promise.all([seenByGuest, seenByWatcher]);
assert.equal((await call(host, 'game:move', { index: 0 })).error, 'not_your_turn');
assert.equal((await call(watcher, 'game:move', { index: 0 })).error, 'not_player');
console.log('✓ مزامنة الحركات ومنع اللعب خارج الدور');

// ترحيل إشارات WebRTC
const sig = waitFor(guest, 'rtc:signal', (d) => d.from === watcher.id);
watcher.emit('rtc:signal', { to: guest.id, data: { test: 1 } });
await sig;
console.log('✓ ترحيل إشارات الصوت');

// صلاحيات: غير المدير لا يستطيع الطرد
assert.equal((await call(guest, 'host:action', { action: 'kick', target: watcher.id })).error, 'not_host');
assert.ok((await call(host, 'host:action', { action: 'allowSpeak', target: watcher.id })).ok);
const kicked = waitFor(watcher, 'room:kicked');
assert.ok((await call(host, 'host:action', { action: 'ban', target: watcher.id })).ok);
assert.equal((await kicked).reason, 'banned');
console.log('✓ الطرد والحظر من المدير فقط');

[host, guest, watcher].forEach((s) => s.close());
console.log('كل الاختبارات نجحت ✅');
process.exit(0);
