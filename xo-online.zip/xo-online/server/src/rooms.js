// إدارة الغرف والصلاحيات — كل القرارات تُتخذ هنا على السيرفر فقط
import crypto from 'crypto';
import { checkResult, emptyBoard } from './game.js';

export const MAX_SPECTATORS = Number(process.env.MAX_SPECTATORS || 12);
const ROOM_TTL_MS = 30 * 60 * 1000; // حذف الغرفة الفارغة بعد 30 دقيقة

const rand = (bytes) => crypto.randomBytes(bytes).toString('base64url');
const safeEq = (a, b) => {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  const ba = Buffer.from(a), bb = Buffer.from(b);
  return ba.length === bb.length && crypto.timingSafeEqual(ba, bb);
};
export const cleanName = (n) =>
  String(n || '').replace(/[<>\u0000-\u001f]/g, '').trim().slice(0, 20) || 'لاعب';

export class Room {
  constructor({ hostName }) {
    this.id = rand(6);
    this.hostKey = rand(24);     // سر المدير — لا يُرسل لأحد غيره
    this.playToken = rand(12);   // رابط دعوة اللاعب الثاني
    this.watchToken = rand(12);  // رابط المشاهدين
    this.hostName = cleanName(hostName);
    this.members = new Map();    // socketId -> member
    this.slots = { X: null, O: null }; // { clientId, name, socketId }
    this.bannedClients = new Set();
    this.bannedIps = new Set();
    this.locked = false;
    this.board = emptyBoard();
    this.starter = 'X';
    this.turn = 'X';
    this.result = null;
    this.scores = { X: 0, O: 0, draw: 0 };
    this.rematchVotes = new Set();
    this.emptySince = Date.now();
  }

  get spectatorCount() {
    let n = 0;
    for (const m of this.members.values()) if (m.role === 'spectator') n++;
    return n;
  }

  findByClient(clientId) {
    for (const m of this.members.values()) if (m.clientId === clientId) return m;
    return null;
  }

  /**
   * دخول عضو. يرجع { ok, member, replacedSocketId } أو { ok:false, error }
   */
  join(socketId, { clientId, name, token, hostKey, ip }) {
    if (typeof clientId !== 'string' || clientId.length < 8 || clientId.length > 64) {
      return { ok: false, error: 'bad_client' };
    }
    name = cleanName(name);
    const isHost = safeEq(hostKey, this.hostKey);

    if (!isHost && this.bannedClients.has(clientId)) return { ok: false, error: 'banned' };

    let role;
    if (isHost) {
      role = 'X';
    } else if (safeEq(token, this.playToken)) {
      const o = this.slots.O;
      if (!o || o.clientId === clientId) role = 'O';
      else role = 'spectator'; // المقعد مأخوذ → يدخل كمشاهد
    } else if (safeEq(token, this.watchToken)) {
      role = 'spectator';
      // إذا كان هذا الجهاز هو اللاعب O سابقًا (إعادة اتصال) نعيده لمقعده
      if (this.slots.O && this.slots.O.clientId === clientId) role = 'O';
    } else {
      return { ok: false, error: 'bad_link' };
    }

    if (role === 'spectator') {
      if (this.bannedIps.has(ip)) return { ok: false, error: 'banned' };
      if (this.locked) return { ok: false, error: 'locked' };
      if (this.spectatorCount >= MAX_SPECTATORS) return { ok: false, error: 'full' };
    }

    // نفس الجهاز مفتوح في تبويب/اتصال آخر → نستبدله
    let replacedSocketId = null;
    const prev = this.findByClient(clientId);
    if (prev) {
      replacedSocketId = prev.socketId;
      this.members.delete(prev.socketId);
    }

    const member = {
      socketId,
      clientId,
      ip,
      name,
      role,
      isHost,
      canSpeak: role !== 'spectator', // اللاعبون يتكلمون، المشاهد يحتاج إذن
      micOn: false,
    };
    if (role !== 'spectator') {
      const slot = this.slots[role];
      // المدير يستطيع منع اللاعب O من الكلام، ونحفظ ذلك عند إعادة الاتصال
      if (slot && slot.clientId === clientId && slot.canSpeak === false) member.canSpeak = false;
      this.slots[role] = { clientId, name, socketId, canSpeak: member.canSpeak };
    }
    this.members.set(socketId, member);
    this.emptySince = null;
    return { ok: true, member, replacedSocketId };
  }

  leave(socketId) {
    const m = this.members.get(socketId);
    if (!m) return null;
    this.members.delete(socketId);
    if (m.role !== 'spectator' && this.slots[m.role]?.socketId === socketId) {
      this.slots[m.role].socketId = null; // المقعد محفوظ لإعادة الاتصال
    }
    this.rematchVotes.delete(m.role);
    if (this.members.size === 0) this.emptySince = Date.now();
    return m;
  }

  isExpired(now = Date.now()) {
    return this.emptySince !== null && now - this.emptySince > ROOM_TTL_MS;
  }

  move(socketId, index) {
    const m = this.members.get(socketId);
    if (!m || (m.role !== 'X' && m.role !== 'O')) return { ok: false, error: 'not_player' };
    if (!this.slots.X?.socketId || !this.slots.O?.socketId) return { ok: false, error: 'waiting_player' };
    if (this.result) return { ok: false, error: 'game_over' };
    if (m.role !== this.turn) return { ok: false, error: 'not_your_turn' };
    if (!Number.isInteger(index) || index < 0 || index > 8) return { ok: false, error: 'bad_cell' };
    if (this.board[index]) return { ok: false, error: 'cell_taken' };

    this.board[index] = m.role;
    const result = checkResult(this.board);
    if (result) {
      this.result = result;
      this.scores[result.winner] += 1;
    } else {
      this.turn = this.turn === 'X' ? 'O' : 'X';
    }
    return { ok: true };
  }

  voteRematch(socketId) {
    const m = this.members.get(socketId);
    if (!m || (m.role !== 'X' && m.role !== 'O')) return { ok: false, error: 'not_player' };
    if (!this.result) return { ok: false, error: 'game_running' };
    this.rematchVotes.add(m.role);
    if (this.rematchVotes.has('X') && this.rematchVotes.has('O')) {
      this.board = emptyBoard();
      this.result = null;
      this.starter = this.starter === 'X' ? 'O' : 'X'; // تبديل من يبدأ
      this.turn = this.starter;
      this.rematchVotes.clear();
    }
    return { ok: true };
  }

  /**
   * أوامر المدير — تُرفض إذا لم يكن المرسل هو المدير فعلًا
   * actions: kick | ban | mute | allowSpeak | lock | unlock | resetScores
   * يرجع { ok, kickedSocketId? }
   */
  hostAction(socketId, { action, target }) {
    const host = this.members.get(socketId);
    if (!host || !host.isHost) return { ok: false, error: 'not_host' };

    if (action === 'lock') { this.locked = true; return { ok: true }; }
    if (action === 'unlock') { this.locked = false; return { ok: true }; }
    if (action === 'resetScores') { this.scores = { X: 0, O: 0, draw: 0 }; return { ok: true }; }

    const t = this.members.get(target);
    if (!t) return { ok: false, error: 'no_target' };
    if (t.isHost) return { ok: false, error: 'cannot_target_host' };

    switch (action) {
      case 'mute':
        t.canSpeak = false;
        if (t.role !== 'spectator') this.slots[t.role].canSpeak = false;
        return { ok: true };
      case 'allowSpeak':
        t.canSpeak = true;
        if (t.role !== 'spectator') this.slots[t.role].canSpeak = true;
        return { ok: true };
      case 'kick':
      case 'ban': {
        if (action === 'ban') {
          this.bannedClients.add(t.clientId);
          if (t.ip) this.bannedIps.add(t.ip);
        }
        this.members.delete(target);
        if (t.role === 'O') {
          // طرد اللاعب الثاني يحرر المقعد لشخص آخر
          this.slots.O = null;
          this.board = emptyBoard();
          this.result = null;
          this.turn = this.starter;
          this.rematchVotes.clear();
        }
        return { ok: true, kickedSocketId: target };
      }
      default:
        return { ok: false, error: 'bad_action' };
    }
  }

  setMic(socketId, on) {
    const m = this.members.get(socketId);
    if (m) m.micOn = !!on && m.canSpeak;
  }

  /** الحالة العامة + بيانات خاصة بكل مستلم */
  stateFor(socketId) {
    const me = this.members.get(socketId);
    const player = (r) => {
      const s = this.slots[r];
      if (!s) return null;
      const m = s.socketId ? this.members.get(s.socketId) : null;
      return {
        id: s.socketId,
        name: s.name,
        online: !!m,
        canSpeak: m ? m.canSpeak : s.canSpeak !== false,
        micOn: m ? m.micOn : false,
        isHost: r === 'X',
      };
    };
    const state = {
      roomId: this.id,
      locked: this.locked,
      board: this.board,
      turn: this.turn,
      result: this.result,
      scores: this.scores,
      rematchVotes: [...this.rematchVotes],
      players: { X: player('X'), O: player('O') },
      spectators: [...this.members.values()]
        .filter((m) => m.role === 'spectator')
        .map((m) => ({ id: m.socketId, name: m.name, canSpeak: m.canSpeak, micOn: m.micOn })),
      speakers: [...this.members.values()].filter((m) => m.canSpeak).map((m) => m.socketId),
      maxSpectators: MAX_SPECTATORS,
      you: me ? { id: me.socketId, role: me.role, isHost: me.isHost, canSpeak: me.canSpeak, name: me.name } : null,
      links: null,
    };
    if (me?.isHost) state.links = { playToken: this.playToken, watchToken: this.watchToken };
    else if (me && me.role !== 'spectator') state.links = { watchToken: this.watchToken };
    return state;
  }
}

export class RoomManager {
  constructor() {
    this.rooms = new Map();
  }
  create(opts) {
    const room = new Room(opts);
    this.rooms.set(room.id, room);
    return room;
  }
  get(id) {
    return typeof id === 'string' ? this.rooms.get(id) : undefined;
  }
  sweep() {
    for (const [id, r] of this.rooms) if (r.isExpired()) this.rooms.delete(id);
  }
}
