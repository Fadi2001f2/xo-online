// منطق لعبة XO الخالص (بدون شبكة) — يسهل اختباره
export const LINES = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8],
  [0, 3, 6], [1, 4, 7], [2, 5, 8],
  [0, 4, 8], [2, 4, 6],
];

export function emptyBoard() {
  return Array(9).fill(null);
}

/** يرجع {winner:'X'|'O'|'draw', line} أو null إذا اللعبة مستمرة */
export function checkResult(board) {
  for (const line of LINES) {
    const [a, b, c] = line;
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return { winner: board[a], line };
    }
  }
  if (board.every(Boolean)) return { winner: 'draw', line: null };
  return null;
}
