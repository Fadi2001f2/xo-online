import express from 'express';
import http from 'http';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { Server } from 'socket.io';
import { RoomManager, cleanName } from './rooms.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3001);
const CLIENT_ORIGIN = process.env.CLIENT_ORIGIN || ''; // للتطوير فقط مثل http://localhost:5173
const CLIENT_DIST = process.env.CLIENT_DIST || path.resolve(__dirname, '../../client/dist');

const app = express();
app.set('trust proxy', process.env.TRUST_PROXY ?? 1); // خلف Caddy/Nginx/Render
app.disable('x-powered-by');
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Permissions-Policy', 'microphone=(self), camera=()');
  next();
});

const server = http.createServer(app);
const io = new Server(server, {
  cors: CLIENT_ORIGIN ? { origin: CLIENT_ORIGIN.split(',') } : undefined,
  maxHttpBufferSize: 64 * 1024,
  pingInterval: 10000,
  pingTimeout: 8000,
});
const rooms = new RoomManager();
setInterval(() => rooms.sweep(), 60 * 1000).unref();

// ---------- ICE (STUN/TURN) ----------
function iceServers() {
  const list = [];
  const stun = (process.env.STUN_URLS || 'stun:stun.l.google.com:19302,stun:stun1.l.google.com:19302')
    .split(',').map((s) => s.trim()).filter(Boolean);
  if (stun.length) list.push({ urls: stun });

  const turnUrls = (process.env.TURN_URLS || '').split(',').map((s) => s.trim()).filter(Boolean);
  if (turnUrls.length) {
    if (process.env.TURN_SECRET) {
      // بيانات مؤقتة متوافقة مع coturn (use-auth-secret) صالحة 12 ساعة
      const username = `${Math.floor(Date.now() / 1000) + 12 * 3600}:xo`;
      const credential = crypto.createHmac('sha1', process.env.TURN_SECRET).update(username).digest('base64');
      list.push({ urls: turnUrls, username, credential });
    } else if (process.env.TURN_USERNAME) {
      list.push({ urls: turnUrls, username: process.env.TURN_USERNAME, credential: process.env.TURN_PASSWORD || '' });
    }
  }
  return list;
}

app.get('/api/ice', (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.json({ iceServers: iceServers() });
});
app.get('/api/health', (req, res) => res.json({ ok: true, rooms: rooms.rooms.size }));

// ---------- الواجهة المبنية (production) ----------
if (fs.existsSync(CLIENT_DIST)) {
  app.use(express.static(CLIENT_DIST, { index: false, maxAge: '1h' }));
  app.get('*', (req, res) => res.sendFile(path.join(CLIENT_DIST, 'index.html')));
}

// ---------- أدوات ----------
function clientIp(socket) {
  const xf = socket.handshake.headers['x-forwarded-for'];
  if (xf && app.get('trust proxy')) return String(xf).split(',')[0].trim();
  return socket.handshake.address;
}

function broadcastState(room) {
  for (const id of room.members.keys()) {
    io.to(id).emit('room:state', room.stateFor(id));
  }
}

// محدد معدل بسيط لكل اتصال لمنع الإغراق
function rateLimit(socket, event) {
  // إشارات WebRTC كثيرة عند الدخول (مرشحات ICE لكل عضو) فلها حد أعلى
  const isSignal = event === 'rtc:signal';
  const max = isSignal ? 400 : 40;
  const windowMs = 2000;
  const key = isSignal ? 'rlSig' : 'rl';
  const now = Date.now();
  const rl = (socket.data[key] ||= { start: now, count: 0 });
  if (now - rl.start > windowMs) { rl.start = now; rl.count = 0; }
  return ++rl.count <= max;
}

const ack = (cb, payload) => { if (typeof cb === 'function') cb(payload); };

function removeFromRoom(socket, room, { notifySelf } = {}) {
  socket.leave(room.id);
  socket.data.roomId = null;
  io.to(room.id).emit('peer:left', { id: socket.id });
  if (notifySelf) socket.emit('room:kicked', notifySelf);
}

// ---------- Socket.IO ----------
io.on('connection', (socket) => {
  socket.use((packet, next) => (rateLimit(socket, packet[0]) ? next() : next(new Error('rate_limited'))));
  socket.on('error', () => {});

  const currentRoom = () => rooms.get(socket.data.roomId);

  socket.on('room:create', ({ name } = {}, cb) => {
    const room = rooms.create({ hostName: cleanName(name) });
    ack(cb, { ok: true, roomId: room.id, hostKey: room.hostKey });
  });

  socket.on('room:join', (payload = {}, cb) => {
    const room = rooms.get(payload.roomId);
    if (!room) return ack(cb, { ok: false, error: 'no_room' });

    // إذا كان في غرفة أخرى نخرجه منها
    const old = currentRoom();
    if (old && old !== room) { old.leave(socket.id); removeFromRoom(socket, old); broadcastState(old); }

    const res = room.join(socket.id, {
      clientId: payload.clientId,
      name: payload.name,
      token: payload.token,
      hostKey: payload.hostKey,
      ip: clientIp(socket),
    });
    if (!res.ok) return ack(cb, res);

    if (res.replacedSocketId && res.replacedSocketId !== socket.id) {
      const oldSock = io.sockets.sockets.get(res.replacedSocketId);
      if (oldSock) removeFromRoom(oldSock, room, { notifySelf: { reason: 'replaced' } });
      else io.to(room.id).emit('peer:left', { id: res.replacedSocketId });
    }

    socket.join(room.id);
    socket.data.roomId = room.id;
    // قائمة الأعضاء الحاليين ليبدأ القادم الجديد اتصالات WebRTC معهم
    const peers = [...room.members.keys()].filter((id) => id !== socket.id);
    ack(cb, { ok: true, peers, state: room.stateFor(socket.id) });
    broadcastState(room);
  });

  socket.on('game:move', ({ index } = {}, cb) => {
    const room = currentRoom();
    if (!room) return ack(cb, { ok: false, error: 'no_room' });
    const r = room.move(socket.id, index);
    ack(cb, r);
    if (r.ok) broadcastState(room);
  });

  socket.on('game:rematch', (_ = {}, cb) => {
    const room = currentRoom();
    if (!room) return ack(cb, { ok: false, error: 'no_room' });
    const r = room.voteRematch(socket.id);
    ack(cb, r);
    if (r.ok) broadcastState(room);
  });

  socket.on('host:action', ({ action, target } = {}, cb) => {
    const room = currentRoom();
    if (!room) return ack(cb, { ok: false, error: 'no_room' });
    const r = room.hostAction(socket.id, { action, target });
    ack(cb, r);
    if (!r.ok) return;
    if (r.kickedSocketId) {
      const s = io.sockets.sockets.get(r.kickedSocketId);
      if (s) removeFromRoom(s, room, { notifySelf: { reason: action === 'ban' ? 'banned' : 'kicked' } });
      else io.to(room.id).emit('peer:left', { id: r.kickedSocketId });
    }
    if (action === 'mute') {
      // إبلاغ المستهدف بإيقاف إرسال الصوت فورًا
      room.setMic(target, false);
      io.to(target).emit('voice:forceMute');
    }
    broadcastState(room);
  });

  socket.on('voice:mic', ({ on } = {}) => {
    const room = currentRoom();
    if (!room) return;
    room.setMic(socket.id, on);
    broadcastState(room);
  });

  // ترحيل إشارات WebRTC — فقط بين أعضاء نفس الغرفة
  socket.on('rtc:signal', ({ to, data } = {}) => {
    const room = currentRoom();
    if (!room || !room.members.has(socket.id) || !room.members.has(to)) return;
    if (!data || typeof data !== 'object') return;
    io.to(to).emit('rtc:signal', { from: socket.id, data });
  });

  socket.on('room:leave', () => {
    const room = currentRoom();
    if (!room) return;
    room.leave(socket.id);
    removeFromRoom(socket, room);
    broadcastState(room);
  });

  socket.on('disconnect', () => {
    const room = currentRoom();
    if (!room) return;
    if (room.leave(socket.id)) {
      io.to(room.id).emit('peer:left', { id: socket.id });
      broadcastState(room);
    }
  });
});

server.listen(PORT, () => {
  console.log(`XO Online server on :${PORT}`);
});

export { app, server, io };
